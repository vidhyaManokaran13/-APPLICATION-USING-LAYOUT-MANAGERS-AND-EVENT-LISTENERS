package com.example.myapplication;


import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText, regNoEditText;
    private Spinner departmentSpinner;
    private TextView displayTextView;
    private String selectedDepartment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.nameEditText);
        regNoEditText = findViewById(R.id.regNoEditText);
        departmentSpinner = findViewById(R.id.departmentSpinner);
        displayTextView = findViewById(R.id.displayTextView);
        Button submitButton = findViewById(R.id.submitButton);

        // Set up the Spinner for department selection
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.departments_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        departmentSpinner.setAdapter(adapter);

        // Capture the selected department
        departmentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedDepartment = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedDepartment = ""; // Default to empty if nothing is selected
            }
        });

        // Handle submit button click
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String regNo = regNoEditText.getText().toString();

                // Display the entered details
                String details = "Name: " + name + "\n" +
                        "Registration No: " + regNo + "\n" +
                        "Department: " + selectedDepartment;
                displayTextView.setText(details);
            }
        });
    }
}
